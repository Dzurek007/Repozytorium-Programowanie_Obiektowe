package TASKS.LAB15.ZADANIA;

public class StartLab15 {
    public static void Start() {
        Menu menu = new Menu();
    }
}
