package TASKS.LAB16;

public class StartLab16 {
    public static void Start(){
        WelcomeForm frame = new WelcomeForm();
    }
}
