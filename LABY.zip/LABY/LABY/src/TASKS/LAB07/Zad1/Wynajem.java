package TASKS.LAB07.zadania_domowe.Zad1;

public interface Wynajem {
    void wypozycz();
    void zwroc();
    double obliczKoszt(int hours);
}
