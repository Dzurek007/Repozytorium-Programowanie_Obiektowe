package TASKS.LAB07.zadania_domowe.Zad2;

public interface IFigury {
    public float getPowierzchnia();
    public boolean wPolu(Punkt p);
}
