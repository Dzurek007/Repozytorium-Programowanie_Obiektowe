package TASKS.LAB07.zadania_domowe.Zad2;

public interface RuchFigury {
    public void przesun(int x, int y);
}
