package TASKS.LAB08.ZadaniaDomowe;

public class NieprawidlowyAdresException extends Exception{
    public NieprawidlowyAdresException (String message){
        super(message);
    }
}
