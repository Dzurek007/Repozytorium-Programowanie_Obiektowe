package TASKS.LAB08.ZadaniaDomowe;

public class BlednaWartoscDlaSilniException extends Exception{
    public BlednaWartoscDlaSilniException (String message){
        super(message);
    }
}
